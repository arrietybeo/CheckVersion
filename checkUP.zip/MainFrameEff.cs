public class MainFrameEff
{
	public Part[] mpart;
}
