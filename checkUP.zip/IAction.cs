public interface IAction
{
	void perform();
}
