public delegate void ActionPaint(mGraphics g, int x, int y);
