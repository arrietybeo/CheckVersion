public class idSaveImage
{
	public short id;

	public sbyte[] mbytImage;

	public idSaveImage(short id, sbyte[] mbyte)
	{
		this.id = id;
		mbytImage = mbyte;
	}
}
