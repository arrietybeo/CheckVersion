public class ImageIcon
{
	public mImage img;

	public short id;

	public long timeRemove;

	public bool isLoad;

	public long timeGetBack;
}
