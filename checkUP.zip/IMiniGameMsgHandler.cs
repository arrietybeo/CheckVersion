public interface IMiniGameMsgHandler
{
	void onMessage(Message msg);
}
