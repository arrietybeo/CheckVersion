public class Cout
{
	public static int count;

	public static void println(string s)
	{
	}

	public static void println(int s)
	{
	}

	public static void Log(string str)
	{
	}

	public static void LogError(string str)
	{
	}

	public static void LogError2(string str)
	{
	}

	public static void LogWarning(string str)
	{
	}
}
