public class MainPartImage
{
	public short x;

	public short y;

	public short w;

	public short h;

	public short ID;

	public MainPartImage(int ID, int x, int y, int w, int h)
	{
		this.ID = (short)ID;
		this.x = (short)x;
		this.y = (short)y;
		this.w = (short)w;
		this.h = (short)h;
	}
}
