public class DelaySkill
{
	public sbyte typeSkill;

	public long timebegin;

	public int value;

	public int limit;

	public bool isSkillAttack;
}
