public class MainTextChat
{
	public string text;

	public sbyte color;

	public MainTextChat(string text, sbyte color)
	{
		this.text = text;
		this.color = color;
	}
}
