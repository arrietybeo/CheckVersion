public class TabAll : MainScreen
{
	public const int TAB = 0;

	public const int MENUSHOP = 1;

	public const int ITEMSHOP = 2;
}
