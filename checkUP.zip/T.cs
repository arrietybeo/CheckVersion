public class T
{
	public static string thanhcong;

	public static string thatbai;

	public static string tathieuung;

	public static string bathieuung;

	public static string khac;

	public static string members;

	public static string thoigianconlai;

	public static string hetlannap;

	public static string hide;

	public static string hidefull;

	public static string annguoichoi;

	public static string hiennguoichoi;

	public static string hoihienguoichoi;

	public static string hoiannguoichoi;

	public static string trangbi1;

	public static string trangbi2;

	public static string quaylai;

	public static string hoprac;

	public static string bonguyenlieu;

	public static string can_not_move;

	public static string NghiBan;

	public static string nhapSlogan;

	public static string hoanthanh;

	public static string nhapsai;

	public static string hoidaugia;

	public static string nhapgiaban;

	public static string daugia;

	public static string gianHang;

	public static string numberHotLine;

	public static string HotLine;

	public static string TimeThachDau;

	public static string chuaboduclo;

	public static string DucLo;

	public static string muaNhieu;

	public static string bongoc;

	public static string hopngoc;

	public static string hetNgoc;

	public static string khongbothem;

	public static string chuaboitem;

	public static string bovao;

	public static string khamNgoc;

	public static string khongcongua;

	public static string Logifail;

	public static string TisNguaNau;

	public static string del;

	public static string username;

	public static string password;

	public static string login;

	public static string menu;

	public static string select;

	public static string close;

	public static string waitLogin;

	public static string nulluserpass;

	public static string next;

	public static string server;

	public static string create;

	public static string level;

	public static string namePlayer;

	public static string nameMin6char;

	public static string back;

	public static string remember;

	public static string hotKey;

	public static string congdiem;

	public static string phim;

	public static string Lv;

	public static string giaotiep;

	public static string createChar;

	public static string buy;

	public static string diemtiemnang;

	public static string diemkynang;

	public static string nhanvat;

	public static string mainQuest;

	public static string subQuest;

	public static string viewMap;

	public static string nhan;

	public static string tra;

	public static string cancel;

	public static string quest;

	public static string chat;

	public static string noMessage;

	public static string delTabChat;

	public static string read;

	public static string view;

	public static string change;

	public static string equip;

	public static string setPoint;

	public static string cong;

	public static string danglaydulieu;

	public static string hoihuyQuest;

	public static string hoiBuy;

	public static string pleaseWait;

	public static string leftRing;

	public static string rightRing;

	public static string hoiDelItem;

	public static string nhapsoluongcanmua;

	public static string khongcovatphanphuhop;

	public static string cong1diem;

	public static string nhapsodiem;

	public static string nhohonhoacbang;

	public static string cong1kynang;

	public static string setKey;

	public static string nhatdcvatpham;

	public static string farfocus;

	public static string party;

	public static string listParty;

	public static string noParty;

	public static string invite;

	public static string mainLeave;

	public static string leave;

	public static string mainCancle;

	public static string addFriend;

	public static string nullParty;

	public static string gianhap;

	public static string lapnhom;

	public static string khacclass;

	public static string buySell;

	public static string khoa;

	public static string fullBuySell;

	public static string kynangchuass;

	public static string price;

	public static string deleteFriend;

	public static string beginChat;

	public static string listFriend;

	public static string nullFriend;

	public static string hoivaonhom;

	public static string hoilapnhom;

	public static string item;

	public static string dungitem;

	public static string use;

	public static string underlevel;

	public static string chuahoc;

	public static string yeucau;

	public static string nangluong;

	public static string delay;

	public static string timebuff;

	public static string hieuung;

	public static string timehieuung;

	public static string tanghpdung;

	public static string tangmpdung;

	public static string phamvi;

	public static string phamvilan;

	public static string somuctieu;

	public static string banthan;

	public static string moinguoi;

	public static string trongdoi;

	public static string kethu;

	public static string buff;

	public static string active;

	public static string passive;

	public static string kynang;

	public static string velang;

	public static string muonvelang;

	public static string sell;

	public static string hoisell;

	public static string LVyeucau;

	public static string yeucauketban;

	public static string chapnhan;

	public static string tuchoi;

	public static string myseft;

	public static string info;

	public static string trochuyen;

	public static string moiParty;

	public static string vucbo;

	public static string coin;

	public static string gem;

	public static string hoithoat;

	public static string exit;

	public static string dangdangnhap;

	public static string hoiFrist;

	public static string oldPlayer;

	public static string newPlayer;

	public static string register;

	public static string help;

	public static string clearData;

	public static string lienhe;

	public static string dacotaikhoan;

	public static string dagoidangky;

	public static string quenpass;

	public static string thulai;

	public static string texthelpRegister;

	public static string lostMana;

	public static string capdochuadu;

	public static string nhandc;

	public static string diemcongvao;

	public static string hoisinh;

	public static string newParty;

	public static string oso;

	public static string loimoiParty;

	public static string moikhoinhom;

	public static string giaitannhom;

	public static string roikhoinhom;

	public static string vuataonhom;

	public static string disconnect;

	public static string hoigiaodich;

	public static string huygiaodich;

	public static string khongthegiaodich;

	public static string chuyentien;

	public static string nhapsotien;

	public static string xacnhan;

	public static string giaodichthanhcong;

	public static string giatrinhapsai;

	public static string banmuongiaodich;

	public static string xincho;

	public static string setPk;

	public static string dosat;

	public static string on;

	public static string off;

	public static string hut;

	public static string voigia;

	public static string la;

	public static string tinden;

	public static string khongthecong;

	public static string changeArea;

	public static string Area;

	public static string nhapsdt;

	public static string trora;

	public static string tinnhan;

	public static string friend;

	public static string logout;

	public static string autoHP;

	public static string auto;

	public static string autoFire;

	public static string timduongtoilang;

	public static string again;

	public static string nhanNv;

	public static string traNv;

	public static string tacdunglen;

	public static string mucdohoanthanh;

	public static string khongthetraodoi;

	public static string xinchogiaodich;

	public static string xacnhangiaodich;

	public static string chuyensang;

	public static string keypad;

	public static string touch;

	public static string Ring;

	public static string menuChinh;

	public static string chucnang;

	public static string khuvuc;

	public static string chimang;

	public static string tatcasatthuong;

	public static string satthuongvatly;

	public static string satthuonglua;

	public static string satthuongdoc;

	public static string satthuongdien;

	public static string nedon;

	public static string phongthu;

	public static string hoihelp;

	public static string endHelp;

	public static string autoItem;

	public static string dangketnoilai;

	public static string vetruoc;

	public static string toitruoc;

	public static string listnull;

	public static string suckhoe;

	public static string yeusuckhoe;

	public static string strhelp;

	public static string tabtrangbi;

	public static string tabthongtin;

	public static string tabkynang;

	public static string tabnhiemvu;

	public static string tabhethong;

	public static string tabchucnang;

	public static string noichuyen;

	public static string download;

	public static string dcxuyengiap;

	public static string dcchimang;

	public static string tabhanhtrang;

	public static string phansatthuong;

	public static string mau;

	public static string khangtatcast;

	public static string xuyengiap;

	public static string satthuongbang;

	public static string giet;

	public static string nhat;

	public static string fullInven;

	public static string helpCapchar;

	public static string cauhinhthap;

	public static string naptien;

	public static string dangdungtocnay;

	public static string dasohuu;

	public static string chapnhanketban;

	public static string hang;

	public static string chuanhapsdt;

	public static string chuanhapmk;

	public static string sdtkhople;

	public static string emailkhople;

	public static string kiemtralai;

	public static string sdt;

	public static string email;

	public static string nangcapyeucau;

	public static string thongbaotuserver;

	public static string khongganmauvaophimnay;

	public static string questitem;

	public static string layra;

	public static string catvao;

	public static string nhapsoluongcanlay;

	public static string nhapsoluongcancat;

	public static string sellmore;

	public static string banhetxanh;

	public static string banhettrang;

	public static string khongcontrang;

	public static string khongconxanh;

	public static string dotrang;

	public static string doxanh;

	public static string chiphi;

	public static string nguyenlieu;

	public static string tilemayman;

	public static string hoac;

	public static string dapdo;

	public static string hoidapxuluong;

	public static string hay;

	public static string setting;

	public static string bovatphamvao;

	public static string dapbangxu;

	public static string chest;

	public static string namenaptien;

	public static string trochuyenvoi;

	public static string noEvent;

	public static string mevent;

	public static string loimoikb;

	public static string moivaoParty;

	public static string loimoigiaodich;

	public static string thachdau;

	public static string hoithachdau;

	public static string loimoithachdau;

	public static string autoBuff;

	public static string thongbao;

	public static string hoichoniconclan;

	public static string iconclan;

	public static string contentclan;

	public static string showAuto;

	public static string addmemclan;

	public static string moivaoclan;

	public static string loimoivaoclan;

	public static string clan;

	public static string bieutuong;

	public static string chuakhauhieu;

	public static string xinvaoclan;

	public static string xemdanhsach;

	public static string gop;

	public static string nhapsoxumuongop;

	public static string nhapsoluongmuongop;

	public static string doiSlogan;

	public static string doiNoiquy;

	public static string phonghacap;

	public static string nhapthongtindoi;

	public static string slogan;

	public static string noiquy;

	public static string thanhvien;

	public static string chucvu;

	public static string moiroiclan;

	public static string roiclan;

	public static string tabThuLinh;

	public static string tabBangHoi;

	public static string chattoanbang;

	public static string doithongbao;

	public static string bankhongconclan;

	public static string soluong;

	public static string donggopclan;

	public static string quyxu;

	public static string quyngoc;

	public static string hoibatdosat;

	public static string update;

	public static string minimap;

	public static string kenhthegioi;

	public static string nhapnoidung;

	public static string chatParty;

	public static string phi;

	public static string replace;

	public static string hoichuyendo;

	public static string qua;

	public static string boitemreplace;

	public static string dochuyen;

	public static string donhan;

	public static string plusnhanduoc;

	public static string noidungnhusau;

	public static string textkenhthegioi;

	public static string text2kenhthegioi;

	public static string nhanban;

	public static string khongconhiemvu;

	public static string timeyeucau;

	public static string taoCanh;

	public static string hoiTaoCanh;

	public static string Lvsudung;

	public static string nangcap;

	public static string sudungsau;

	public static string phandon;

	public static string hoiroiClan;

	public static string updateData;

	public static string updateok;

	public static string hoinangcapcanh;

	public static string listserver;

	public static string SetMusic;

	public static string maychu;

	public static string tuoi;

	public static string tancong;

	public static string choan;

	public static string lockMap;

	public static string delMess;

	public static string khongthedung;

	public static string about;

	public static string textabout1;

	public static string textabout2;

	public static string nokiaprivacy;

	public static string thoigianaptrung;

	public static string aptrung;

	public static string nhaptaikhoan;

	public static string choimoi;

	public static string moly;

	public static string startdraw;

	public static string choitiep;

	public static string choi;

	public static string chonlai;

	public static string choi_daco_TK;

	public static string daco_TK;

	public static string doi_TK_khac;

	public static string minutes;

	public static string yes;

	public static string no;

	public static string hopNguyenLieu;

	public static string hopThanh;

	public static string YOUNEED;

	public static string backBattlefield;

	public static string infoArena;

	public static string textXuongNgua;

	public static string textHoiXuongNgua;

	public static string speedUp;

	public static string Tips;

	public static string TchangSv;

	public static string TuseNgua;

	public static string[] textCreateChar;

	public static string[] mClass;

	public static string[] mKyNang;

	public static string[] story;

	public static string[] mColorPk;

	public static string[] mAuto;

	public static string[] mUtien;

	public static string[] helpMenu;

	public static string[] mAutoItem;

	public static string[] mhang;

	public static string[] mChucVuClan;

	public static string[] mVolume;

	public static string[] mQuest;

	public static string[] mKynangPet;

	public static string[] mQuickChat;

	public static string[] mTips;

	public static string[] mapName;

	public static string[][] mCreateChar_HAIR;

	public static string[][] mCreateChar_EYE_FACE;

	public static string[][] mHelp;

	public static string[][] mHelpPoint;

	public static string[][] mValueAutoItem;

	public static string changeScrennSmall;

	public static string normalScreen;

	public static string changeSizeScreen;

	public T()
	{
		thanhcong = "Cường hóa thành công";
		thatbai = "Cường hóa thất bại";
		tathieuung = "Tắt hiệu ứng";
		bathieuung = "Bật hiệu ứng";
		khac = "Khác";
		members = "Thành viên: ";
		thoigianconlai = "Thời gian còn lại ";
		hiennguoichoi = "Hiện người chơi";
		hoihienguoichoi = "Bạn có muốn hiện những người chơi khác";
		hoiannguoichoi = "Bạn có muốn ẩn những người chơi khác";
		annguoichoi = "Ẩn người chơi";
		trangbi1 = "T.Bị 1";
		trangbi2 = "T.Bị 2";
		quaylai = "Quay Lại";
		hoprac = "Tạo";
		bonguyenlieu = "Nhà ngươi hãy bỏ nguyên liệu vào, ta sẽ ghép cho";
		can_not_move = "Bạn không thiể di chuyển khi đang bán hàng, Bạn có muốn nghỉ bán không";
		nhapSlogan = "Nhập tên cửa hàng";
		hoanthanh = "Hoàn Thành";
		nhapsai = "Nhập sai vui lòng nhập lại";
		hoidaugia = "Bạn có muốn bán: ";
		nhapgiaban = "Nhập giá bán";
		daugia = "Bán";
		gianHang = "Gian Hàng";
		NghiBan = "Nghỉ Bán";
		numberHotLine = string.Empty;
		HotLine = string.Empty;
		TimeThachDau = "Thách đấu bắt đầu sau: ";
		chuaboduclo = "Hãy bỏ bùa huyền bí và vật phẩm của nhà ngươi vào rồi ta sẽ đục lỗ cho.";
		DucLo = "Đục lỗ";
		muaNhieu = "Mua Nhiều";
		bongoc = "Nhà ngươi hãy bỏ ngọc vào, ta sẽ ghép ngọc cho";
		hopngoc = "Hợp ngọc";
		hetNgoc = "Nhà ngươi đã hết ngọc loại này rồi, hãy ra ngoài đánh quái để thu thập rồi mang về đây cho ta";
		khongbothem = "Không thể bỏ thêm";
		chuaboitem = "Nhà ngươi hãy bỏ vũ khí và ngọc vào ta sẽ khảm cho.";
		bovao = "Bỏ vào";
		khamNgoc = "Khảm Ngọc";
		khongcongua = "Bạn không thú cưỡi trong hành trang.";
		Logifail = "Kết nối thất bại, vui lòng kiểm tra lại đường truyền.";
		Tips = "Tips: ";
		mapName = new string[92]
		{
			"Ngôi Làng Nhỏ",
			"Làng Sói Trắng",
			"Khu mỏ",
			"Bìa Rừng",
			"Hang Lửa",
			"Rừng Ảo Giác",
			"Khe Vực",
			"Cánh Đồng Sói",
			"Thung Lũng Kỳ Bí",
			"Hồ Ký Ức",
			"Bãi Đất Trống",
			"Bờ Biển",
			"Vực Đá",
			"Rặng Đá Ngầm",
			"Nghĩa Địa Tàu Đắm",
			"Đầm Lầy",
			"Đền Cổ",
			"Hang Dơi",
			"Hang Sói Quỷ",
			"Cửa Biển",
			"Sa Mạc",
			"Đồi Cát",
			"Vực Lún",
			"Hố Tử Thần",
			"Nghĩa địa cát",
			"Rừng Chết",
			"Suối Ma",
			"Thung Lũng Đá",
			"Boss Guardian",
			"Hầm Mộ Tầng 1",
			"Hầm Mộ Tầng 2",
			"Hầm Mộ Tầng 3",
			"Hầm mộ quái vật",
			"Thành Phố Kho Báu",
			"Khu phía Tây",
			"Khu phía Đông",
			"Đấu Trường",
			"Rừng cao nguyên",
			"Con đường hiểm trở",
			"Vách đá cheo leo",
			"Núi Cầu Vòng",
			"Lối lên Thượng giới",
			"Đèo hoang sơ",
			"Đường xuống lòng đất",
			"Cây cầu ma ám",
			"Cổng vào Hạ giới",
			"Đấu Trường",
			"Đồi xác chết",
			"Ngã tư tử thần",
			"Phó bản mới",
			"Khu vườn",
			"Cổng thiên đàng",
			"Cổng địa ngục",
			"Chuẩn bị",
			"Làng ánh sáng",
			"Chuẩn bị",
			"Làng gió",
			"Chuẩn bị",
			"Làng sét",
			"Chuẩn bị",
			"Làng lửa",
			"Chiến trường",
			"Địa ngục tầng 1",
			"Rừng medusa",
			"Rừng Chimera",
			"Rừng quái vật",
			"Thác reo",
			"Thành phố cảng",
			"Khu bờ nam",
			"Khu bờ bắc",
			"Khu bờ tây",
			"Rừng chuột",
			"Rừng hoa đỏ",
			"Vịnh Caribe",
			"Mê cung",
			"Mê cung tầng 1",
			"Mê cung tầng 2",
			"Mê cung tầng 3",
			"Mê cung tầng 4",
			"Mê cung tầng cuối",
			"Thi đấu",
			string.Empty,
			"Khu mua bán",
			"Cửa đông",
			"Cửa tây",
			"Cửa nam",
			"Cửa bắc",
			"Đấu trường",
			"Map 88",
			"Map 89",
			"Map 90",
			"Map 91"
		};
		mTips = new string[13]
		{
			"Nhấn giữ nút chat 2s sẽ bật khung chat nhanh.", "Thùng may mắn xuất hiện mỗi giờ ngẫu nhiên các bản đồ.", "Một bang hội có thể chiếm nhiều mỏ tài nguyên.", "Săn quái và thách đấu sẽ tăng điểm danh vọng.", "Điểm danh vọng tụt giảm nếu hiệp sĩ không hoạt động trong một thời gian.", "Hoàn thành phó bản có thể kiếm được trứng thú nuôi.", "Ghi danh chiến trường với Mr. Ballard ở Hang Lửa.", "Boss sẽ tái sinh sau 12 tiếng tính từ lúc bị đánh chết.", "Cường hóa vật phẩm sẽ ngẫu nhiên được Khúc Xương.", "Con Ma sẽ xuất hiện sau khi hiệp sĩ đạt level 20.",
			"Sức khỏe có thể phục hồi khi đứng yên hoặc dùng thức ăn.", "Đồng Tyche hiệp sĩ sẽ có thể vào khu hai giờ miễn phí.", "Trong khu 2 giờ tỉ lệ rớt đồ và kinh nghiệm sẽ cao hơn các khu khác."
		};
		mQuickChat = new string[20]
		{
			"Chào!", "muahahaha!!!", "Đợi một chút!", "Gà quá!", "Pro quá!", "Lag quá!", "Party không?", "Anh em tập trung", "Đi nào anh em!", "Chiếm mỏ thôi mọi người",
			"Săn boss mọi người ơi!", "Đứa nào dám đồ sát ta!", "Đông quá vậy", "PK không thằng kia?", "Ai cho vào bang với!", "Bang tuyển thành viên chăn onl!", "Đi ngủ đi", "Bye!", "Nguy hiểm chạy lẹ!!!", "Cứu tôi với HELP!!"
		};
		TchangSv = "Bạn vừa chuyển qua Server Việt Nam, vui lòng sử dụng tài khoản khác để đăng nhập";
		TuseNgua = "Thú cưỡi";
		TisNguaNau = "Xuống ngựa để tấn công!";
		speedUp = "Tăng tốc";
		textXuongNgua = "Xuống Ngựa";
		textHoiXuongNgua = "Ngựa sẽ bị mất khi xuống ngựa, Bạn có muốn xuống ngựa không ?";
		infoArena = "Thông tin chiến trường:";
		backBattlefield = "Tham gia chiến trường sau: ";
		yes = "Đồng ý";
		no = "Không";
		choimoi = "Chơi Mới";
		choi_daco_TK = "Chơi Tiếp";
		daco_TK = "Có Tài Khoản";
		doi_TK_khac = "Đổi Tài Khoản";
		minutes = "phút";
		changeScrennSmall = "Màn hình nhỏ";
		normalScreen = "Màn hình lớn";
		changeSizeScreen = "Bạn có muốn thoát game để thay đổi màn hình không ? ";
		del = "Xóa";
		username = "Tài khoản";
		password = "Mật khẩu";
		login = "Đăng nhập";
		menu = "Menu";
		select = "Chọn";
		close = "Đóng";
		waitLogin = "Đang đăng nhập vui lòng chờ.";
		nulluserpass = "Vui lòng nhập tên và mật khẩu.";
		next = "Tiếp";
		server = "Server";
		create = "Tạo";
		level = "Cấp: ";
		Lv = "Lv";
		namePlayer = "Tên nhân vật";
		nameMin6char = "Tên nhân vật phải dài hơn 5 ký tự.";
		back = "Trở về";
		remember = "Nhớ mật khẩu";
		hotKey = "Phím tắt";
		congdiem = "Cộng điểm";
		phim = "Phím ";
		giaotiep = "Giao tiếp";
		createChar = "Tạo mới";
		buy = "Mua";
		diemtiemnang = "Điểm tiềm năng: ";
		diemkynang = "Điểm kỹ năng: ";
		nhanvat = "Nhân vật: ";
		mainQuest = "Nhiệm vụ chính:";
		subQuest = "Nhiệm vụ phụ:";
		viewMap = "Bản đồ";
		nhan = "Nhận";
		tra = "Hoàn thành";
		cancel = "Hủy";
		quest = "Nhiệm vụ";
		chat = "Chat";
		noMessage = "Bạn không có tin nhắn";
		delTabChat = "Đóng tab này";
		read = "Đọc";
		view = "Xem";
		change = "Thay đổi";
		equip = "Trang bị";
		setPoint = "Cộng điểm";
		cong = "Cộng";
		danglaydulieu = "Đang lấy dữ liệu";
		hoihuyQuest = "Bạn có muốn hủy nhiệm vụ ";
		hoiBuy = "Bạn muốn mua ";
		pleaseWait = "Vui lòng chờ.";
		leftRing = "Nhẫn trái";
		rightRing = "Nhẫn phải";
		hoiDelItem = "Bạn muốn bỏ ";
		nhapsoluongcanmua = "Nhập số lượng cần mua:";
		khongcovatphanphuhop = "hành trang không có vật phẩm phù hợp.";
		cong1diem = "Bạn muốn công 1 điểm vào ";
		nhapsodiem = "Nhập vào số điểm bạn muốn cộng vào ";
		nhohonhoacbang = " (nhỏ hơn hoặc bằng ";
		cong1kynang = "Bạn muốn công 1 diểm vào kỹ năng ";
		setKey = "Gán phím";
		nhatdcvatpham = "Nhặt được vật phẩm";
		farfocus = "Mục tiêu ở quá xa";
		party = "Đội nhóm";
		noParty = "Bạn không có nhóm.";
		invite = "Mời thêm";
		mainLeave = "Yêu cầu rời đội";
		leave = "rời đội";
		mainCancle = "Giải tán đội";
		addFriend = "Kết bạn";
		nullParty = "Không có đội ở gần";
		gianhap = "Gia nhập";
		lapnhom = "Tạo nhóm";
		khacclass = "Bạn không thể dùng đồ của trường phái khác.";
		listParty = "Danh sách nhóm";
		hoithachdau = " gởi cho bạn một lời mời thách đấu. Mức cược là ";
		khoa = "Khóa";
		fullBuySell = "Mỗi lần giao dịch tối đa 9 vật phẩm.";
		kynangchuass = "Kỹ năng chưa sẵn sàng";
		price = "Giá";
		deleteFriend = "Bạn muốn xóa người này ra khỏi danh sách?";
		beginChat = "Trò chuyện với ";
		listFriend = "Danh Sách Bạn Bè";
		nullFriend = "Làm quen nhiều người hơn nào.";
		hoivaonhom = "Bạn muốn vào đội ";
		hoilapnhom = "Bạn muốn lập 1 đội?";
		item = "Vật phẩm";
		dungitem = "Bạn muốn dùng vật phẩm này?";
		use = "Sử dụng";
		underlevel = "Cấp độ chưa đủ.";
		chuahoc = "Chưa học kỹ năng này.";
		yeucau = "Yêu cầu ";
		nangluong = "Hao tốn MP: ";
		delay = "thời gian hồi: ";
		timebuff = "thời gian hổ trợ: ";
		hieuung = "hiệu ứng: ";
		timehieuung = "thời gian h.ứng: ";
		tanghpdung = "tăng HP nạp: ";
		tangmpdung = "tăng MP nạp: ";
		phamvi = "Phạm vi: ";
		phamvilan = "Phạm vi lan: ";
		somuctieu = "Số mục tiêu: ";
		banthan = "bản thân";
		moinguoi = "mọi người";
		trongdoi = "đội";
		kethu = "đối thủ";
		buff = "Bổ trợ";
		active = "Tấn công";
		passive = "Bị động";
		kynang = "Kỹ năng ";
		velang = "Về làng";
		muonvelang = "Bạn có muốn về làng hồi máu?";
		sell = "Bán";
		hoisell = "Bạn muốn bán ";
		LVyeucau = "Lv yêu cầu: ";
		yeucauketban = " muốn kết bạn. Bạn có đồng ý không?";
		chapnhan = "Chấp nhận";
		tuchoi = "Từ chối";
		myseft = "Hành Trang - Nhân vật";
		info = "Thông tin";
		trochuyen = "Trò chuyện";
		moiParty = "Mời vào nhóm";
		vucbo = "Vứt bỏ";
		coin = "vàng";
		gem = "ngọc";
		hoithoat = "Bạn muốn thoát khỏi trò chơi";
		exit = "Thoát";
		dangdangnhap = "Đang kết nối đến máy chủ. Vui lòng chờ.";
		hoiFrist = "Bạn đã từng chơi và có tài khoản Hiệp Sĩ Online từ trước?";
		oldPlayer = "Đã có";
		newPlayer = "Chưa có";
		register = "Đăng ký";
		help = "Hỗ trợ";
		clearData = "Xóa dữ liệu";
		lienhe = "Bạn có muốn lấy lại (hoặc đổi) mật khẩu?";
		dacotaikhoan = "Đã có tài khoản";
		dagoidangky = "Đã gởi thông tin đăng ký. Vui lòng chờ xác nhận.";
		quenpass = "Quên m.khẩu";
		thulai = "Quá trình xử lý quá lâu.Bạn vui lòng thử lại.";
		texthelpRegister = string.Empty;
		lostMana = "Không đủ năng lượng.";
		capdochuadu = "Cấp độ bạn chưa đủ";
		nhandc = ". Bạn sẽ nhận được:";
		diemcongvao = " điểm cộng vào ";
		hoisinh = "Hồi sinh";
		newParty = "Tạo đội mới";
		oso = "ô số ";
		loimoiParty = " muốn mời bạn vào nhóm. Bạn có đồng ý không?";
		moikhoinhom = "Bạn đã bị mời khỏi nhóm.";
		giaitannhom = "Nhóm bạn đã bị giải tán.";
		roikhoinhom = "Bạn đã rời khỏi nhóm.";
		vuataonhom = "Nhóm của bạn vừa được tạo thành công.";
		disconnect = "Bạn bị mất kết nối với máy chủ.";
		hoigiaodich = " muốn mời bạn giao dịch. Bạn có đồng ý không?";
		buySell = "Giao dịch";
		huygiaodich = "Giao dịch của bạn đã bị hủy.";
		khongthegiaodich = "Bạn không thể giao dịch vật phẩm nhiệm vụ";
		chuyentien = "Chuyển tiền";
		nhapsotien = "Nhập vào số tiền bạn muốn giao dịch (nhỏ hơn bằng 10 triệu).";
		xacnhan = "Xác nhận";
		giaodichthanhcong = "Giao dịch đã hoàn tất.";
		giatrinhapsai = "Giá trị nhập nhiều hơn số tiền bạn đang có.";
		banmuongiaodich = "Bạn đã kiểm tra kỹ và muốn giao dịch?";
		xincho = "Xin chờ";
		setPk = "Đeo cờ";
		dosat = "đồ sát";
		on = "Bật";
		off = "Tắt";
		hut = "né đòn";
		voigia = "Với giá ";
		la = "là";
		tinden = "Tin đến";
		khongthecong = "Số điểm cộng tối đa của bạn là ";
		changeArea = "Chuyển khu vực";
		Area = "Khu ";
		nhapsdt = "Nhập số điện thoại, email";
		trora = "Đóng trò chuyện";
		tinnhan = "Tin nhắn";
		friend = "Bạn bè";
		logout = "Đăng xuất";
		autoHP = " Tự bơm máu";
		auto = "Tự động";
		autoFire = " Tự động đánh";
		timduongtoilang = "phải mau tìm tới làng sói trắng theo lời mẹ thôi.";
		again = "Thử lại";
		nhanNv = "Nhận NV ";
		traNv = "Trả NV ";
		tacdunglen = "Tác dụng lên";
		mucdohoanthanh = "Mức độ hoàn thành ";
		khongthetraodoi = "Không thể trao đổi vật phẩm này";
		xinchogiaodich = "xin chờ ";
		xacnhangiaodich = " xác nhận giao dịch";
		chuyensang = "Chuyển sang ";
		keypad = "keypad";
		touch = "touch";
		Ring = "Nhẫn";
		menuChinh = "MENU";
		chucnang = "Chức năng";
		khuvuc = "Khu vực";
		chimang = "Chí mạng: ";
		tatcasatthuong = "Tất cả sát thương: ";
		satthuongvatly = "Sát thương vật lý: ";
		satthuonglua = "Sát thương lửa: ";
		satthuongdoc = "Sát thương độc: ";
		satthuongdien = "Sát thương điện: ";
		nedon = "Né đòn: ";
		phongthu = "Phòng thủ: ";
		hoihelp = "Bạn có muốn thực hiện phần hướng dẫn người chơi mới. Vui lòng chọn Tiếp nếu muốn, Hủy nếu không. Bạn cũng có thể tắt hướng dẫn bằng cách vào menu - chức năng - tắt hướng dẫn";
		endHelp = "Tắt hướng dẫn";
		dangketnoilai = "Đang kết nối lại. Vui lòng chờ.";
		vetruoc = "Về trang ";
		toitruoc = "Tới trang ";
		listnull = "Không có ai trong danh sách";
		suckhoe = "Sk: ";
		yeusuckhoe = "Không đủ sức khỏe";
		tabhanhtrang = "Hành Trang";
		tabtrangbi = "Trang Bị";
		tabthongtin = "Nhân Vật";
		tabkynang = "Kỹ Năng";
		tabnhiemvu = "Nhiệm Vụ";
		tabhethong = "Thiết Lập";
		tabchucnang = "Chức Năng";
		strhelp = "-Phím bấm\n  + Dùng các phím điều hướng hoặc 2,4,6,8 để di chuyển.\n  + Phím 5 (hoặc phím giữa),1,3,7,9 để sử dụng các tuyệt chiêu và bơm máu, năng lượng.\n  + Phím * để bật khung chat, phím 0 để chuyển tab dùng tuyệt chiêu.\n-NPC\n  +Lisa và Emma: Bán máu, năng lượng và phục hồi thể lực.\n  +Doubar và Alisama: Bán các trang bị như áo, quần, gang tay ...\n  +Aman và Amin: rương đồ của bạn sẽ rất an toàn khi có họ.\n  +Hammer và Black eye: Bán vũ khí.\n  +Đá dịch chuyển: giúp bạn đi lại giữa các khu vực với nhau.\n  +Zulu: thầy phù thủy giúp bạn thay đổi kiểu tóc và cũng là người giao các nhiệm vụ hằng ngày.\n  +Pháp sư: là người bán nguyên liệu cũng như giúp bạn cường hóa trang bị.\n  +Zoro và Benjamin: sẽ giúp bạn tạo Bang hội, và các vật phẩm Bang cũng được bán từ họ.\n  +Phó thống lĩnh: là người đưa bạn đến các Phó bảng.\n  +Tiên cánh: sẽ giúp bạn có được những đôi cánh sức mạnh và cũng rất đẹp đấy.";
		noichuyen = "Nói chuyện";
		download = "Tải";
		dcchimang = "chí mạng";
		dcxuyengiap = "xuyên giáp";
		mau = "Máu: ";
		khangtatcast = "Kháng tất cả sát thương: ";
		xuyengiap = "Xuyên giáp: ";
		nangluong = "Năng lượng: ";
		satthuongbang = "Sát thương băng: ";
		phansatthuong = "Phản sát thương: ";
		giet = "Diệt ";
		nhat = "Nhặt ";
		autoItem = " Tự nhặt đồ";
		fullInven = "Hành trang đầy";
		helpCapchar = "Hãy bấm đúng các ký tự gợi ý để tiêu diệt con ma!";
		cauhinhthap = " cấu hình thấp";
		naptien = "Nạp";
		dangdungtocnay = "Bạn đang sử dụng bộ tóc này.";
		dasohuu = "Đã sở hữu";
		chapnhanketban = " đã chấp nhận lời mời kết bạn.";
		hang = "Hạng";
		chuanhapsdt = "Bạn chưa nhập email hoặc số di động.";
		chuanhapmk = "Bạn chưa nhập mật khẩu";
		sdtkhople = "Số di động không hợp lệ. Xin nhập theo mẫu 0912345678 hoặc 84918765432";
		emailkhople = "Email không hợp lệ. Xin nhập theo mẫu tencuaban@yahoo.com hoặc tencuaban@gmail.com";
		kiemtralai = "Xin kiểm tra chính xác để có thể lấy lại được tài khoản trong trường hợp quên mật khẩu.";
		sdt = "Số di động: ";
		email = "Địa chỉ mail: ";
		nangcapyeucau = "Nâng cấp cần: Lv ";
		thongbaotuserver = "Thông báo từ server";
		khongganmauvaophimnay = "Vật phầm không thể gán vào phím này.";
		questitem = "Vật phẩm nhiệm vụ";
		layra = "Lấy ra";
		catvao = "Cất vào";
		nhapsoluongcanlay = "Nhập số lượng cần lấy ra:";
		nhapsoluongcancat = "Nhập số lượng cần cất vào:";
		sellmore = "Bán nhiều";
		banhetxanh = "Bán hết đồ xanh +0";
		banhettrang = "Bán hết đồ trắng +0";
		khongconxanh = "Không còn món đồ xanh nào trong hành trang.";
		khongcontrang = "Không còn món đồ trắng nào trong hành trang.";
		dotrang = " đồ trắng.";
		doxanh = " đồ xanh.";
		chiphi = "Chi phí:";
		nguyenlieu = "Nguyên liệu:";
		tilemayman = "Tỉ lệ may mắn:";
		hoac = " hoặc ";
		dapdo = "Cường hóa";
		hoidapxuluong = "Mi muốn cường hóa trang bị bằng ";
		hay = " hay ";
		setting = "Cài đặt";
		bovatphamvao = "Hãy bỏ trang bị muốn cường hóa vào, ta sẽ giúp mi.";
		dapbangxu = "Mi muốn cường hóa trang bị này với ";
		chest = "Rương đồ";
		namenaptien = "Nạp tiền";
		trochuyenvoi = "Trò chuyện với ";
		noEvent = "Danh sách rỗng";
		mevent = "Sự kiện";
		loimoikb = "Yêu cầu kết bạn.";
		moivaoParty = "Mời bạn vào nhóm.";
		loimoigiaodich = "Mời bạn giao dịch.";
		thachdau = "Thách đấu";
		loimoithachdau = "Lời mời thách đấu.";
		autoBuff = "Tự động Buff";
		thongbao = "Thông báo";
		hoichoniconclan = "Bạn muốn chọn biểu tượng này cho clan của mình?";
		iconclan = "Biểu tượng Clan";
		contentclan = "Biểu tượng đặc trưng cho bang hội.";
		showAuto = " hiện thông tin";
		addmemclan = "Mời vào Bang";
		moivaoclan = " muốn mời bạn gia nhập Bang.";
		loimoivaoclan = "Lời mời vào Bang.";
		clan = "Bang hội";
		bieutuong = "Biểu tượng: ";
		chuakhauhieu = "chưa có khẩu hiệu.";
		xinvaoclan = "Xin vào Hội";
		xemdanhsach = "Danh sách thành viên";
		gop = "Góp ";
		nhapsoxumuongop = "Nhập số vàng bạn muốn góp vào Bang hội.";
		nhapsoluongmuongop = "Nhập số ngọc bạn muốn góp vào Bang hội.";
		doiSlogan = "Thay đổi khẩu hiệu";
		doiNoiquy = "Thay đổi nội quy";
		phonghacap = "Phong/Hạ cấp";
		nhapthongtindoi = "Vui lòng nhập thông tin bạn muốn thay đổi.";
		slogan = "Khẩu hiệu";
		noiquy = "Nội quy";
		thanhvien = "Thành viên";
		chucvu = "Chức vụ: ";
		moiroiclan = "Yêu cầu rời Bang";
		roiclan = "Rời Bang";
		tabThuLinh = "Thủ lĩnh";
		tabBangHoi = "Bang Hội";
		chattoanbang = "Chat Bang";
		doithongbao = "Thay đổi thông báo";
		bankhongconclan = "Bạn không còn trong Bang.";
		soluong = "Số lượng: ";
		donggopclan = "Đóng góp Bang";
		quyxu = "Quỹ xu: ";
		quyngoc = "Quỹ ngọc: ";
		hoibatdosat = "Bạn muốn bật chế độ đồ sát?";
		update = "Cập nhật";
		minimap = "Bản đồ nhỏ";
		textkenhthegioi = "Chat kênh Thế giới";
		text2kenhthegioi = "Kênh TG - ";
		kenhthegioi = "Bạn có muốn chat kênh thế giới ";
		noidungnhusau = " với nội dung như sau:";
		nhapnoidung = "Nhập nội dung";
		chatParty = "Chat đội nhóm";
		phi = "Phí";
		replace = "Chuyển hóa";
		hoichuyendo = "Mi có muốn chuyển cấp cường hóa từ ";
		qua = " qua ";
		dochuyen = "Đồ chuyển: ";
		donhan = "Đồ nhận: ";
		plusnhanduoc = "Kết quả chuyển hóa:";
		boitemreplace = "Hãy bỏ 2 vật phẩm muốn hoán đổi cường hóa vào. Phần còn lại cứ để ta.";
		nhanban = "nhân bản";
		khongconhiemvu = "Không có nhiệm vụ";
		timeyeucau = "Thời gian ncấp: ";
		taoCanh = "Tạo cánh";
		hoiTaoCanh = "Hiệp sĩ có muốn tạo ";
		Lvsudung = "cấp độ yêu cầu ";
		nangcap = "nâng cấp";
		sudungsau = "Sử dụng sau ";
		phandon = "Phản đòn";
		hoiroiClan = "Bạn muốn rời khỏi Bang hội?";
		updateData = "Đang cập nhật dữ liệu, vui lòng chờ!";
		updateok = "Dữ liệu mới đã được cập nhật.";
		hoinangcapcanh = "Hiệp sĩ có muốn nâng cấp ";
		mVolume = new string[2] { "Nhạc nền: ", "Hiệu ứng: " };
		listserver = "Chọn Máy Chủ";
		SetMusic = "Âm thanh";
		maychu = "Máy chủ ";
		tuoi = "Tuổi: ";
		tancong = "Tấn công: ";
		choan = "Cho ăn";
		lockMap = "Chức năng bản đồ đang tạm khóa.";
		delMess = "Xóa sự kiện";
		khongthedung = "Không thể sử dụng.";
		about = "Giới thiệu";
		textabout1 = "Knight Age Online\nVersion: ";
		textabout2 = "Silver Bat Studio (VN)\nSound by www.freesound.org\nMusic by audionautix.com\nFor Help: knight.online.ssvn@gmail.com";
		nokiaprivacy = "Điều khoản";
		thoigianaptrung = "Thời gian nở ";
		aptrung = "Ấp Trứng";
		nhaptaikhoan = "Nhập tài khoản (nếu có)";
		choi = "Chơi";
		moly = "Mở ly";
		startdraw = "Bắt đầu";
		choitiep = "Chơi tiếp";
		chonlai = "Chọn lại";
		hopNguyenLieu = "Hãy đặt vào 5 nguyên liệu cùng loại, cấp muốn hợp, ta sẽ giúp cho. ";
		hopThanh = "Hợp thành";
		YOUNEED = "Bạn cần phải có";
		mhang = new string[4] { "Nhất", "Nhì", "Ba", "Tư" };
		mChucVuClan = new string[7] { "Thủ Lĩnh", "Phó Chỉ Huy", "Đại Hiệp Sĩ", "Hiệp Sĩ Cao Quý", "Hiệp Sĩ Danh Dự", "Thành Viên Mới", "Đã rời khỏi Bang" };
		mChucVuClan = new string[7] { "Thủ Lĩnh", "Phó Chỉ Huy", "Đại Hiệp Sĩ", "Hiệp Sĩ Cao Quý", "Hiệp Sĩ Danh Dự", "Thành Viên Mới", "Đã rời khỏi Bang" };
		story = new string[2] { "Hơn 500 năm trước khi chiến tranh giữa hai vương quốc Thượng giới và Hạ giới nổ ra, dân chúng không có được một ngày bình yên. Họ luôn phải sống trong tâm trạng lo lắng không chỉ bởi cuộc chiến mà còn những câu chuyện về sự xuất hiện của rất nhiều quái vật sống dậy từ cõi chết.", "Chính vì thế những Hiệp Sĩ của tự do xuất hiện với sứ mệnh làm thay đổi cả thế giới, thời đại của những Hiệp Sĩ bắt đầu." };
		mKynangPet = new string[4] { "Nhóm SM", "Nhóm KL", "Nhóm TL", "Nhóm TT" };
		textCreateChar = new string[4] { "Trường phái", "Tóc", "Mắt", "Đầu" };
		mClass = new string[4] { "Chiến Binh", "Sát thủ", "Pháp Sư", "Xạ Thủ" };
		mCreateChar_HAIR = new string[2][]
		{
			new string[2] { "Rơm", "Bụi" },
			new string[2] { "Dài", "Ngắn" }
		};
		mCreateChar_EYE_FACE = new string[2][]
		{
			new string[4] { "Đen", "Xanh", "Đen", "Xanh" },
			new string[2] { "Tròn", "Yêu tinh" }
		};
		mKyNang = new string[4] { "Sức Mạnh", "Khéo Léo", "Thể Lực", "Tinh Thần" };
		mColorPk = new string[10] { "Tháo cờ", "Đỏ", "Xanh lá", "Xanh dương", "Tím", "Vàng", "Cam", "Hồng", "Xanh da trời", "Đen" };
		mAuto = new string[2] { "Sử dụng HP khi còn dưới ", "Sử dụng MP khi còn dưới" };
		mUtien = new string[2] { "Ưu tiên: < nhỏ đến lớn >", "Ưu tiên: < lớn đến nhỏ >" };
		mAutoItem = new string[3] { "Vật phẩm: ", "MP,HP: ", "Vàng: " };
		mValueAutoItem = new string[3][]
		{
			new string[6] { "nhặt tất cả", "nhặt từ đồ xanh", "nhặt từ đồ vàng", "nhặt từ đồ tím", "nhặt từ đồ cam", "không nhặt" },
			new string[4] { "nhặt tất cả", "chỉ nhặt HP", "chỉ nhặt MP", "không nhặt" },
			new string[2] { "nhặt", "không nhặt" }
		};
		helpMenu = new string[1] { "chọn vào đây" };
		mQuest = new string[2] { "đang làm", "đã xong" };
		mHelp = new string[10][]
		{
			new string[5] { "Chào mừng bạn đến với thế giới của các hiệp sĩ", "Sau đây là phần hướng dẫn người chơi mới", "Dùng phím lên, xuống, trái phải để di chuyển nhân vật.", "Bạn cũng có thể sử dụng các phím điều hướng để di chuyển theo ý mình", "Giờ bạn hãy di chuyển đến vị trí màu vàng trên màn hình" },
			new string[10]
			{
				"Rất tốt,tiếp theo bạn hãy dùng phím 5 hoặc phím chọn để đánh 1 con quái.",
				"Dấu mũi tên phía trên chính là dấu hiệu nhận biết bạn đang nhắm tới con quái đó",
				string.Empty,
				"Giết 1 con quái cũng dễ thôi đúng không nào. Khi đánh vào những con quái bạn sẽ nhận được một lượng điểm kinh nghiệm.",
				"Ngoài ra còn có thể nhặt được vật phẩm nữa. Giờ hãy thử đánh vài con quái để kiểm chứng nhé.",
				string.Empty,
				"Vật phẩm bạn nhặt được sẽ cất vào trong hành trang",
				"Hãy vào hành trang xem ta có gì trong đấy nào",
				"Để vào đó bạn hãy nhấn phím chọn trái, chọn mục Hành trang -  Nhân vật.",
				"Nhấn chọn trái để vào hành trang."
			},
			new string[13]
			{
				"Đây là hành trang nơi cất giữ mọi thứ cho bạn", "Hiện thời bạn đang có một vài bình máu, năng lượng và cả 1 đôi giày.", "Hãy thử sử dụng bình máu bằng cách di chuyển khung chọn màu trắng đến bình máu", "Bấm phím chọn trái và chọn mục sử dụng", "Nhấn phím chọn và chọn sử dụng", "Rất tốt, ngoài ra bạn còn có thể dùng các bình máu và năng lượng bằng một cách nữa", "Đó là gắn chúng vào phím tắt để có thể thao tác nhanh", "Hãy lại di chuyển khung chọn tới bình máu 1 lần nữa và nhấn chọn.", "Lần này thì hãy chọn gán phím và chọn 1 phím mà bạn thấy là thuận tay nhất nha.", "Nhấn phím chọn và chọn mục gán phím",
				"Nhấn phím chọn và chọn mục gán phím", "Việc sử dụng năng lượng cũng tương tự như thế.", "Bạn hãy thử dùng và gắn phím khi cần thiết nha."
			},
			new string[9] { "Trong hành trang của bạn còn có thêm 1 đôi giày", "Ngoài tác dụng làm đẹp thì đôi giày này còn giúp bạn mạnh mẽ hơn đấy", "Việc mang nó cũng tương tự như là sử dụng máu", "Giờ bạn thử đeo nó vào nha", "Nhấn phím chọn rồi chọn mục sử dụng", "Cũng đơn giản thôi phải không nào.", "Bất cứ vật phẩm nào bạn mặc trên người sẽ xuất hiện trong Trang bị", "Và đây chính là Trang bị của bạn hãy chọn vào để xem ta có gì nào ", "Di chuyển khung chọn tới đây" },
			new string[10] { "Đây chính là phần Trang bị giúp cho bạn biết được mình đang có những gì trên người", "Phần bên trái hiển thị nhân vật và thông tin sức khỏe,điểm pk của bạn", "Bên phải là thông tin về sát thương, phòng thủ và % kháng bạn đang có", "Còn dưới này là chính là các vật phẩm bạn đang có trên người", "Khi bạn có một món đồ trong Hành trang và muốn mặc vào người", "Bạn cũng có thể vào đây chọn đúng vị trí tương ứng và chọn thay đổi", "Ngoài ra nó còn giúp bạn so sánh khi có nhiều món đồ cùng loại nữa", "Hãy thử chức năng này khi bạn nhặt dc 1 vài món đồ nào đó", "Giờ hãy trở ra để tiếp tục cuộc phiêu lưu thôi", "Nhấn phím chọn phải để thoát ra" },
			new string[8]
			{
				string.Empty,
				"Đây là bản đồ nhỏ giúp bạn có 1 góc nhìn lớn hơn về khu vực đang đứng",
				"Hãy chú ý đến điểm chớp màu vàng trên bản đồ đó chính là nơi bạn cần đến",
				"Phần thông tin về máu, năng lượng, cấp độ của bạn là đây.",
				"Khi bạn chọn đến 1 mục tiêu nào đó thì thông tin mục tiêu sẻ hiện ở đây.",
				"Nếu muốn thay đổi mục tiêu bạn chỉ cần nhấn phím chọn phải.",
				"Bạn có đến 2 thanh kỹ năng hãy dúng phím 0 thay đổi",
				"Phím * dùng để chat và phím # sẽ giúp bạn mở phần sự kiện của mình."
			},
			new string[3] { "Bạn vừa lên được 1 cấp, và sẽ có rất nhiều điều hay ho khi lên cấp mà bạn cần phải biết", "Giờ thì hãy vào Hành Trang - Nhân vật xem nào.", "Nhấn chọn trái để vào hành trang" },
			new string[10] { "Đây là phần Thông tin nơi cung cấp cho bạn mọi thứ về chỉ số của bản thân", "Đây là 4 mục Sức mạnh, Khéo léo, Thể lực, Tin thần.", "Mỗi lần lên cấp thì mổi mục sẽ được cộng thêm 1 điểm", "Ngoài ra bạn sẽ có 5 điểm để cộng thêm vào, và cộng vào đâu, đúng hay sai do chính bạn quyết định.", "Phần bên dưới chính là toàn bộ thông tin về chỉ số của bạn", "Giờ ta hãy thử cộng vào Sức Khỏe vài điểm để thấy sự thay đổi.", "Di chuyển tới đây và nhấn chọn", "Rất tốt, chỉ số của bạn đã tăng lên 1 ít rồi.", "Khi lên cấp thì kỹ năng của bạn cũng được nâng cao, hãy vào xem thử nào.", "Di chuyển khung chọn tới đây" },
			new string[11]
			{
				"Đây là phần Kỹ Năng, nơi cho bạn biết tất cả các tuyệt chiêu mình có thể học.",
				"Các dãy bên trái là kỹ năng Vật lý",
				"Khi muốn biết thông tin về kỹ năng đó bạn chỉ cần chọn vào nó.",
				"Bên phải là các kỹ năng ma thuật.",
				"Mỗi khi lên 1 cấp bạn sẽ có 1 điểm kỹ năng để cộng vào",
				"Và cũng như điểm tiềm năng cộng vào đâu đó là tùy quyết định của bạn.",
				"Giờ hãy cộng vào 1 kỹ năng, nhớ xem kỹ thông tin xem bạn thích hợp với cái nào hơn nha.",
				"Chọn vào 1 kỹ năng rồi nhấn cộng điểm",
				"Được rồi,và cũng như bình máu bạn có thể gán vào phím để sử dụng nhanh.",
				"Hãy gán vào 1 phím nào đó rồi ra ngoài kiểm tra sức mạnh của nó xem sao.",
				string.Empty
			},
			new string[8]
			{
				"Bạn vừa nhận một nhiệm vụ mới,hãy vào Hành Trang - Nhân vật để xem lại thông tin nhiệm vụ đó nào.",
				"Di chuyển khung chọn tới đây",
				"Đây chính là mục nhiệm vụ giúp bạn quản lý thông tin nhiệm vụ của mình",
				"Thẻ bên trái là tổng hợp tất cả nhiệm vụ bạn đang làm.",
				"Thẻ bên phải là các nhiệm vụ đã xong và có thể trả.",
				"Khi muốn biết thêm thông tin về nhiệm vụ nào đó chỉ cần bạn di chuyển mục chọn tới đó, rồi nhấn xem.",
				"Bạn cũng có thể xem phần bản đồ lớn để biết rõ hơn về vị trí hiện tại cũng như nới cần phải đến.",
				string.Empty
			}
		};
		mHelpPoint = new string[10][]
		{
			new string[5]
			{
				string.Empty,
				string.Empty,
				"Dùng các phím điều hướng để di chuyển",
				"Bạn cũng có thể chạm vào các vùng trống trên màn hình nếu muốn di chuyển đến đó khi kich hoạt chức năng Touch",
				string.Empty
			},
			new string[10]
			{
				Main.isPC ? "Rất tốt,tiếp tục nhé." : "Rất tốt,tiếp theo bạn hãy chạm vào đây để đánh 1 con quái.",
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Để vào đó bạn hãy nhấn vào Menu hoặc vào khung thông tin phía trên.",
				"Chạm vào đây để vào hành trang."
			},
			new string[13]
			{
				string.Empty,
				string.Empty,
				"Hãy thử sử dụng bình máu bằng cách chạm vào bình máu",
				"Chạm 1 lần nữa để bất menu và chọn mục sử dụng",
				"Chạm vào đây và chọn sử dụng",
				string.Empty,
				string.Empty,
				"Hãy lại Chọn bình máu 1 lần nữa",
				string.Empty,
				"Chạm vào đây và chọn mục gán phím",
				"Chạm vào đây và chọn mục gán phím",
				string.Empty,
				string.Empty
			},
			new string[9]
			{
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Chạm vào đây và chọn sử dụng",
				string.Empty,
				string.Empty,
				string.Empty,
				"Chạm vào đây để mở Trang Bị"
			},
			new string[10]
			{
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Chạm vào đây để trở lại"
			},
			new string[8]
			{
				string.Empty,
				"Đây là bản đồ nhỏ giúp bạn có 1 góc nhìn lớn hơn về khu vực đang đứng",
				"Hãy chú ý đến điểm chớp màu vàng trên bản đồ đó chính là nơi bạn cần đến",
				string.Empty,
				"Khi bạn chọn đến 1 mục tiêu nào đó thì thông tin mục tiêu sẻ hiện ở đây.",
				"Nếu muốn thay đổi mục tiêu bạn chỉ cần chạm vào mục tiêu đó.",
				"Bạn có đến 2 thanh kỹ năng hãy chạm vào đây để thay đổi",
				"Khi cần giao tiếp những người đứng gần thì hãy chạm vào đây để chat nha."
			},
			new string[3]
			{
				string.Empty,
				string.Empty,
				"Chạm vào đây và chọn Hành trang-Nhân vật"
			},
			new string[10]
			{
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Chạm vào đây để cộng điểm.",
				string.Empty,
				string.Empty,
				"Chạm vào đây để mở Kỹ Năng"
			},
			new string[11]
			{
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Chọn vào 1 kỹ năng rồi nhấn cộng điểm",
				string.Empty,
				string.Empty,
				string.Empty
			},
			new string[8]
			{
				string.Empty,
				"Chạm vào đây để mở Nhiệm Vụ",
				string.Empty,
				string.Empty,
				string.Empty,
				"Khi muốn biết thêm thông tin về nhiệm vụ nào đó bạn chỉ cần chạm vào nó.",
				string.Empty,
				string.Empty
			}
		};
	}
}
