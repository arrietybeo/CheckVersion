public class Part
{
	public short x;

	public short y;

	public sbyte idPartImage;
}
