public class TabSkills : MainTabNew
{
}
