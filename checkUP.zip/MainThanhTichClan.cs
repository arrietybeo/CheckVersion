public class MainThanhTichClan
{
	public sbyte id;

	public sbyte num;

	public string nameThanhTich;

	public MainThanhTichClan(sbyte id, sbyte num, string name)
	{
		this.id = id;
		this.num = num;
		nameThanhTich = name;
	}
}
