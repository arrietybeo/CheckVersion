public delegate void ActionChat(string str);
