public class TemGraphics
{
	public mGraphics g;
}
