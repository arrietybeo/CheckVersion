public enum TouchScreenKeyboardType
{
	Default = 0,
	ASCIICapable = 1,
	NumberPad = 2
}
